package com.autuskey.findmystuff.models;

/**
 * Created by SM on 06-Feb-2016 006.
 */
public class StuffModel {
    private String Name = "";
    private String StuffImageUri = "";
    private String Place = "";
    private String PlaceImageUri = "";
    private String Tags = "";

    public String getName() {
        return this.Name;
    }

    public String getStuffImageUri() {
        return StuffImageUri;
    }

    public String getPlace() {
        return Place;
    }

    public String getPlaceImageUri() {
        return PlaceImageUri;
    }

    public String getTags() {
        return Tags;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public void setStuffImageUri(String uri) {
        this.StuffImageUri = uri;
    }

    public void setPlace(String place) {
        this.Place = place;
    }

    public void setPlaceImageUri(String uri) {
        this.PlaceImageUri = uri;
    }

    public void setTags(String tags) {
        this.Tags = tags;
    }
}
