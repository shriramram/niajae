package com.autuskey.findmystuff;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.autuskey.findmystuff.dto.StuffDataDTO;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity  {
    private MyDBHandler dbHandler = null;
    private ArrayList<StuffDataDTO> stuffDataDTOArrayList = new ArrayList<StuffDataDTO>();
    private ListView stuffListView = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            dbHandler = new MyDBHandler(this);
            /*String dbString = dbHandler.databaseToString();
            String dbString = dbHandler.databaseToObject();
             userData = dbString.split(",\n");*/
        stuffDataDTOArrayList = dbHandler.getStuffDataFromDB();
        if(stuffDataDTOArrayList != null && stuffDataDTOArrayList.size()>0){
            listView();
        }else{
            Toast.makeText(this,"You have no stuff dear! Need not worry about any of them. \n\r", Toast.LENGTH_SHORT );
            this.finish();
        }

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    } //end of onCreate

    private void initViews(){

    }
    public void listView(){
//        ListAdapter listAdap = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stringArray);
        stuffListView = (ListView) findViewById(R.id.stuffListView);
        ListAdapter listAdap = new CustomListAdapter(this, stuffDataDTOArrayList);
        stuffListView.setAdapter(listAdap);

        stuffListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                StuffDataDTO dataDTO =stuffDataDTOArrayList.get(position);
                Toast.makeText(MainActivity.this, "Name : "+ stuffDataDTOArrayList.get(position).getStuffname(), Toast.LENGTH_LONG).show();
                // Log the fields to check if we got the info we want
            Log.i("SomeTag", "name: " + stuffDataDTOArrayList.get(position).getStuffname());
            Log.i("SomeTag", "place: " + stuffDataDTOArrayList.get(position).getStuffplace());
            Log.i("SomeTag", "image: " + stuffDataDTOArrayList.get(position).getStufftags());


            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void btnNewStuff_Click(View v){
        Intent myIntent = new Intent("com.autuskey.findmystuff.CreateActivity");
        startActivity(myIntent);
    }


}
