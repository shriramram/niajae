package com.autuskey.findmystuff;

/**
 * Created by SM on 02-Feb-2016 002.
 */
public class Stuffs {
    private int _id;
    private String _stuffName;
    private String _stuffPlace;
    private String _imageName;
    private String _stuffTags;

    public Stuffs(){

    }

    public Stuffs(String stuffName, String stuffPlace, String imageName, String stuffTags) {
        this._stuffName = stuffName;
        this._stuffPlace = stuffPlace;
        this._imageName = imageName;
        this._stuffTags = stuffTags;
    }

    public void set_stuffName(String stuffName) {
        this._stuffName = stuffName;
    }

    public void set_stuffPlace(String stuffPlace) {
        this._stuffPlace = stuffPlace;
    }

    public void set_imageName(String imageName) {
        this._stuffName = imageName;
    }

    public void set_stuffTags(String stuffTags) {
        this._stuffName = stuffTags;
    }

    public String get_stuffName() {
        return _stuffName;
    }

    public String get_stuffPlace() {
        return _stuffPlace;
    }

    public String get_imageName() {
        return _imageName;
    }

    public String get_stuffTags() {
        return _stuffTags;
    }
}
