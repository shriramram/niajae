package com.autuskey.findmystuff.models;

/**
 * Created by SM on 06-Feb-2016 006.
 */
public class SqlStuffModel {
    public static String Name = "name";
    public static String Place = "place";
    public static String StuffImage = "stuff_image";
    public static String PlaceImage = "place_image";
    public static String Tags = "tags";
}
