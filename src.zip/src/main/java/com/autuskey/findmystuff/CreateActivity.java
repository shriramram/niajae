package com.autuskey.findmystuff;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;
import android.widget.ImageView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CreateActivity extends AppCompatActivity {

    private static final int REQUEST_CAMERA = 1;
    private static final int SELECT_FILE = 1;
    EditText caStuffName, caStuffPlace, caStuffTags;
    //    TextView caTextLabel;
    MyDBHandler dbHandler;
    static final int REQUEST_IMAGE_CAPTURE = 1;
    ImageView stuffImageView;
    Uri imageUri = null;
    Button stuffImageBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Bind the events of stuffName
        bindStuffNameEvents();
        //Bind the events of stuff Place
        bindStuffPlaceEvents();
        //Bind the events of stuff Tags
        bindStuffTagsEvents();

        caStuffName = (EditText) findViewById(R.id.caStuffName);
        caStuffPlace = (EditText) findViewById(R.id.caStuffPlace);
        caStuffTags = (EditText) findViewById(R.id.caStuffTags);
//        caTextLabel = (TextView) findViewById(R.id.caTextLabel);
        dbHandler = new MyDBHandler(this);

        stuffImageBtn = (Button) findViewById(R.id.stuffImageBtn);
        stuffImageView = (ImageView) findViewById(R.id.stuffImageView);

        //disable button if user has no camera
        if (!hasCamera()) {
            stuffImageBtn.setEnabled(false);
        }

    }

    //check for camera availability
    public boolean hasCamera() {
        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);
    }

   private static final int SELECT_PHOTO = 100;

    public void showMenu(View view) {
        this.selectImage(view);
    }

    private void selectImage(View view) {
        final CharSequence[] items = { "Take Photo", "Choose from Library",
                "Cancel" };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (items[item].equals("Take Photo")) {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
                } else if (items[item].equals("Choose from Library")) {
                    Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                    photoPickerIntent.setType("image/*");
                    startActivityForResult(photoPickerIntent, SELECT_PHOTO);
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private String getPictureName() {
        String str = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
        String timeStamp = sdf.format(new Date());
        str = "stuff_" + timeStamp + ".jpg";
        return str;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            //get the picture
            Bundle extras = data.getExtras();
            Bitmap photo = (Bitmap) extras.get("data");
            stuffImageView.setImageBitmap(photo);
        } else if(requestCode == SELECT_PHOTO && resultCode == RESULT_OK ){
            Uri selectedImageUri = data.getData();
            stuffImageView.setImageURI(selectedImageUri);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    }

    public void bindStuffNameEvents() {
        try {
            final TextView stuffNameLabel = (TextView) findViewById(R.id.caStuffNameLabel);
            EditText stuffName = (EditText) findViewById(R.id.caStuffName);
            stuffName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (hasFocus) {
                        stuffNameLabel.setVisibility(View.VISIBLE);
                    } else {
                        stuffNameLabel.setVisibility(View.INVISIBLE);
                    }
                }
            });
        } catch (Exception ex) {

        }
    }

    public void bindStuffPlaceEvents() {
        try {
            final TextView stuffPlaceLabel = (TextView) findViewById(R.id.caStuffPlaceLabel);
            EditText stuffPlace = (EditText) findViewById(R.id.caStuffPlace);
            stuffPlace.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (hasFocus) {
                        stuffPlaceLabel.setVisibility(View.VISIBLE);
                    } else {
                        stuffPlaceLabel.setVisibility(View.INVISIBLE);
                    }
                }
            });
        } catch (Exception ex) {

        }
    }

    public void bindStuffTagsEvents() {
        try {
            final TextView stuffTagLabel = (TextView) findViewById(R.id.caStuffTagLabel);
            EditText stuffTags = (EditText) findViewById(R.id.caStuffTags);
            stuffTags.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (hasFocus) {
                        stuffTagLabel.setVisibility(View.VISIBLE);
                    } else {
                        stuffTagLabel.setVisibility(View.INVISIBLE);
                    }
                }
            });
        } catch (Exception ex) {

        }
    }

    public void onStoreBtnClick(View v) {
        try {

            if (caStuffName.getText().toString().length() > 0 && caStuffPlace.getText().toString().length() > 0) {
                /**
                 * setting drawingcache
                 */
                stuffImageView.setDrawingCacheEnabled(true);
                stuffImageView.buildDrawingCache(true);

                stuffImageView.buildDrawingCache();
                Bitmap bmap = stuffImageView.getDrawingCache();
                String imageFileName = getPictureName();

                //test code
                try{
                    String path = Environment.getExternalStorageDirectory().toString();
                    OutputStream fOut = null;
                    File file = new File(path, "/Pictures/findmystuff/");
                    file.mkdirs();
                    file = new File(path+"/Pictures/findmystuff/"+imageFileName);
                    fOut = new FileOutputStream(file);

                    bmap.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
//                    fOut.flush();
                    fOut.close();

                    MediaStore.Images.Media.insertImage(getContentResolver()
                            ,file.getAbsolutePath(),file.getName(),file.getName());

                }catch (Exception e) {
                    e.printStackTrace();
                    //alert
                    AlertDialog alertDialog = new AlertDialog.Builder(CreateActivity.this).create();
                    alertDialog.setTitle("Info");
                    alertDialog.setMessage("Error : "+e.getMessage());
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                    //alert
                }
                //test code

                Stuffs stuff = new Stuffs(caStuffName.getText().toString(), caStuffPlace.getText().toString(), imageFileName, caStuffTags.getText().toString());
                /**
                 * after saving images, saving DB
                 */
                dbHandler.addStuff(stuff);

                /**
                 * resetting input feilds
                 */
                caStuffName.setText("");
                caStuffPlace.setText("");
//                stuffImageView.clearAnimation();
                /**
                 * user info message for completion of the add stuff event
                 */
                Toast.makeText(CreateActivity.this, "Voila!\n\r Stuff Added.", Toast.LENGTH_SHORT).show();
//                printDatabase();
            } else {
                Toast.makeText(CreateActivity.this, "Hey there!\n\r You Forgot To Type !!!.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ex) {
            Log.d(ex.getMessage(), ex.getCause().toString());
        }
    }

}
